package com.kafka.apache.delevery_app_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeleveryAppServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeleveryAppServiceApplication.class, args);
		System.out.println("delevery-app-service.........");
	}

}

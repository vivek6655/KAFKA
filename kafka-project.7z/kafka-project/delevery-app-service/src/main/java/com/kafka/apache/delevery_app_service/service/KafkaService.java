package com.kafka.apache.delevery_app_service.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.kafka.apache.delevery_app_service.kafka.AppConstant;

@Service
public class KafkaService {
	
	private Logger LOGGER=LoggerFactory.getLogger(KafkaService.class);
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	public boolean updateLocation(String location) {
		kafkaTemplate.send(AppConstant.LOCATION_TOPIC_NAME, location);
		LOGGER.info("location updated................................................................----------------------------------------------------- : "+location);
		return true;
		
	}

}

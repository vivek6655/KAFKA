package com.kafka.apache.delevery_app_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeleveryAppServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.user_app_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserAppServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserAppServiceApplication.class, args);
		System.out.println("user-app-service.........");
	}

}

package com.kafka.apache.delevery_app_service.kafka;

public class AppConstant {
	
	public static final String LOCATION_TOPIC_NAME="location-update-topic";

}

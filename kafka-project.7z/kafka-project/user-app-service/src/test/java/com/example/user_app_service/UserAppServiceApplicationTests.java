package com.example.user_app_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAppServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
